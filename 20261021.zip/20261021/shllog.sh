#!/bin/zsh

tail -f ./logs/app.log

