#!/bin/zsh

SHL_HOME=$(cd "$(dirname "$0")" && pwd)

# echo "SHL_HOME=$SHL_HOME"

cp="$SHL_HOME/lib/*:$SHL_HOME/setting"

# echo $cp

java  -cp $cp "-Dshlisp.home=$SHL_HOME"   io.github.shlisp.mvinterp.CuiMainEx  $@

