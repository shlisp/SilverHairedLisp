# 1. インストール先（このスクリプトが置いてある場所）を覚えておく
#    カレントディレクトリは移動しない（起動した場所 = 作業フォルダのまま Java に渡す）
$SHL_HOME = $PSScriptRoot

# 2. 文字コードをUTF-8に設定（文字化け対策）
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.Encoding]::UTF8

# 3. ログ監視ウィンドウを別ターミナル（新しいPowerShell）で起動
#    ログはインストール先の logs に出る（setting/logback.xml の LOG_DIR）
New-Item -ItemType Directory -Force -Path "logs" | Out-Null
Start-Process powershell -ArgumentList "-NoProfile", "-Command", "[Console]::OutputEncoding = [System.Text.Encoding]::UTF8; chcp 65001 > `$null; Get-Content 'logs\app.log' -Encoding utf8 -Wait -Tail 20"

# 4. Javaの実行（@args をつけることで、実行時に渡された引数をそのままJavaに引き渡せます）
#    -Dshlisp.home : インストール先。Java 側は System.getProperty("shlisp.home") で取れる
#    作業フォルダは System.getProperty("user.dir") で取れる
$cp = "$SHL_HOME\lib\*;$SHL_HOME\setting"
java -cp $cp "-Dshlisp.home=$SHL_HOME"  io.github.shlisp.mvinterp.CuiMainEx @args
