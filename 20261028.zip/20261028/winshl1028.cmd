@echo off
chcp 65001 > nul
setlocal

set "SHL_HOME=%~dp0"
if "%SHL_HOME:~-1%"=="\" set "SHL_HOME=%SHL_HOME:~0,-1%"

if not exist "%SHL_HOME%\logs" mkdir "%SHL_HOME%\logs"

start powershell -NoProfile -Command "[Console]::OutputEncoding = [System.Text.Encoding]::UTF8; chcp 65001 > $null; Get-Content '%SHL_HOME%\logs\app.log' -Encoding utf8 -Wait -Tail 20"

set "CP=%SHL_HOME%\lib\*;%SHL_HOME%\setting"

java -cp "%CP%" "-Dshlisp.home=%SHL_HOME%" io.github.shlisp.mvinterp.CuiMainEx %*

endlocal

