#!/bin/zsh

SHL2_HOME="${0:A:h}"

D="${SHL2_HOME}/lib"
CP="${SHL2_HOME}/lib/*"

java -Xss256m --enable-native-access=ALL-UNNAMED -cp "$CP" io.github.shlisp.interp.Main "$@"

